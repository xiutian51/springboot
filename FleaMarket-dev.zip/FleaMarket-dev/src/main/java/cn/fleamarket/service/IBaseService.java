package cn.fleamarket.service;

import com.baomidou.mybatisplus.extension.service.IService;
/**
 * @author zining
 */
public abstract class IBaseService implements IService {

}
