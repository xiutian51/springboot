package cn.fleamarket.service.impl;

import cn.fleamarket.service.OrderService;
import org.springframework.stereotype.Service;


/**
 * @author zining
 */
@Service
public class OrderServiceImpl implements OrderService {

}