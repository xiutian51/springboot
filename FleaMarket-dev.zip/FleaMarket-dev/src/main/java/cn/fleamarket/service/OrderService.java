package cn.fleamarket.service;

import java.util.Map;

/**
 * 订单表
 *
 * @author zining
 * @email ${email}
 * @date 2019-11-12 10:46:22
 */
public interface OrderService{
}

