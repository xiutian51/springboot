package cn.fleamarket.service;

import cn.fleamarket.domain.Image;

import java.util.Map;

/**
 * 图片表
 *
 * @author zining
 * @email ${email}
 * @date 2019-11-12 10:46:22
 */
public interface ImageService{
    int insert(Image image);
}

