package cn.fleamarket.mapper;

import cn.fleamarket.domain.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author zining
 */
@Mapper
public interface OrderMapper extends BaseMapper<Order> {

}
