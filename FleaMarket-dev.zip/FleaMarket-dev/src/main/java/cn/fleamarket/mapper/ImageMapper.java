package cn.fleamarket.mapper;

import cn.fleamarket.domain.Image;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author zining
 */
@Mapper
public interface ImageMapper extends BaseMapper<Image> {
}
